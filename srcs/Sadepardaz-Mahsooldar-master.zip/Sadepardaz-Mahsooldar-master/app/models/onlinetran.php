<?php

class Onlinetran extends AppModel
{
	var $name = 'Onlinetran';
}

?>