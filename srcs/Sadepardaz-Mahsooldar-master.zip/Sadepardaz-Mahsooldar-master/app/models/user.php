<?php
class User extends AppModel
{
	var $name = "User";
}
?>